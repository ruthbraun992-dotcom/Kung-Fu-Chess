
// BoardMapper.hpp
#pragma once
#include "model/Board.hpp"
#include "model/Position.hpp"
#include <optional>

namespace BoardMapper {
    constexpr int CELL_SIZE = 100;
    std::optional<Position> pixelToCell(int x, int y, const Board& board);
}